#include "serialPort/SerialPort.h"
#include <csignal>

// bool RUNNING = true;

// void ShutDown(int sig){
// 	std::cout << "stop the controller" << std::endl;
//     RUNNING = false;
// }

int main(){
    // set the serial port name
    SerialPort serial("/dev/ttyUSB0");

    // send message struct
    MOTOR_send motor_run, motor_stop;
    // receive message struct
    MOTOR_recv motor_r;

    // set the id of motor
    motor_run.id = 0;
    // set the motor type, A1Go1 or B1
    motor_run.motorType = MotorType::B1;
    motor_run.mode = 10;
    motor_run.T = 0.0;
    motor_run.W = 30.0;
    motor_run.Pos = 0.0;
    motor_run.K_P = 0.0;
    motor_run.K_W = 3.0;

    motor_stop.id = motor_run.id;
    motor_stop.motorType = motor_run.motorType;
    motor_stop.mode = 0.0;

    motor_r.motorType = motor_run.motorType;

    modify_data(&motor_run);
    modify_data(&motor_stop);

    // turn for 3 second
    for(int i(0); i<3; ++i){
        serial.sendRecv(&motor_run, &motor_r);
        usleep(1000000);
    }

    // stop the motor
    while(!serial.sendRecv(&motor_stop, &motor_r)){
        usleep(100000);
    }

    return 0;
}
